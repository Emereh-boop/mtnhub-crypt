<script>
  import Layout from "../+layout.svelte";
</script>

<Layout>
  <!-- <nav class="w-full">
    <ul class="flex justify-center font-normal text-[14px] text-gray-100">
      <li class="border-b-[3px] mb-[3px] border-b-black py-2 px-9">
        <a href="/" class=" text-black font-bold">WiFi</a>
      </li>
    </ul>
    <hr />
  </nav> -->
  <slot />
</Layout>

<script>
  import Router from "svelte-spa-router";
  import routes from "./routes";
  import "./index.css";
</script>

<main>
  <Router {routes} />
</main>
